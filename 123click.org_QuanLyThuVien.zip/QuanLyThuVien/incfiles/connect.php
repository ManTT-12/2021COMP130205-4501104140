<?php
	$db_host = "localhost";
	$db_name = "quanlythuvien";
	$db_user = "adminHwgIGuc";
	$db_password = "bNA-8al_95Hs";
	mysql_connect($db_host,$db_user,$db_password) or die("Lỗi kết nối CSDL");
	mysql_select_db($db_name);

?>